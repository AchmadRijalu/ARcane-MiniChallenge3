//
//  SpellViewModel.swift
//  ARcane-MiniChallenge3
//
//  Created by Achmad Rijalu on 01/08/23.
//

import Foundation

class SpellViewModel : ObservableObject{
    @Published var isShooted:Bool = false
}
